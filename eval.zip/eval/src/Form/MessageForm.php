<?php


namespace App\Form;

use App\Entity\Message;
use App\Entity\User;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Security\Core\Security;

class MessageForm extends AbstractType
{
    private Security $security;

    public function __construct(Security $security)
    {
        $this->security = $security;
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $currentUser = $this->security->getUser();

        $builder
            ->add('titre', TextType::class, [
                'label' => 'Objet',
                'attr' => ['placeholder' => 'Ex : Entretien à suivre']
            ])
            ->add('contenu', TextareaType::class, [
                'label' => 'Message',
                'attr' => ['rows' => 6, 'placeholder' => 'Votre message ici...']
            ])
            ->add('receveur', EntityType::class, [
                'class' => User::class,
                'label' => 'Destinataire',
                'query_builder' => function (EntityRepository $er) use ($currentUser) {
                    return $er->createQueryBuilder('u')
                        ->where('u != :current')
                        ->setParameter('current', $currentUser);
                },
                'choice_label' => fn(User $u) => $u->getPrenom() . ' ' . $u->getNom(),
                'placeholder' => 'Choisir un utilisateur',
            ])
            ->add('reponseA', EntityType::class, [
                'class' => Message::class,
                'required' => false,
                'label' => 'En réponse à (facultatif)',
                'choice_label' => fn(Message $msg) => $msg->getTitre(),
                'placeholder' => 'Aucun',
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Message::class,
        ]);
    }
}
