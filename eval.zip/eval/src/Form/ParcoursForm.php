<?php

namespace App\Form;

use App\Entity\Parcours;
use App\Entity\User;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Doctrine\ORM\EntityRepository;

class ParcoursForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('objet')
            ->add('description')
            ->add('user', EntityType::class, [
                'class' => User::class,
                'label' => 'Candidat concerné',
                'query_builder' => function (EntityRepository $er) {
                    return $er->createQueryBuilder('u')
                        ->where('JSON_CONTAINS(u.roles, :role) = 1')
                        ->setParameter('role', json_encode('ROLE_CANDIDAT'));
                },
                'choice_label' => fn(User $user) => $user->getPrenom() . ' ' . $user->getNom(),
                'placeholder' => 'Sélectionner un candidat',
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Parcours::class,
        ]);
    }
}
