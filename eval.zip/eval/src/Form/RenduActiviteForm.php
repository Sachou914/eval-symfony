<?php

namespace App\Form;

use App\Entity\Etape;
use App\Entity\Message;
use App\Entity\RenduActivite;
use App\Entity\Ressource;
use App\Entity\User;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RenduActiviteForm extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('urlDocument')
            ->add('dateHeure', null, [
                'widget' => 'single_text',
            ])
            ->add('user', EntityType::class, [
                'class' => User::class,
                'choice_label' => 'id',
            ])
            ->add('etapes', EntityType::class, [
                'class' => Etape::class,
                'choice_label' => 'id',
                'multiple' => true,
            ])
            ->add('message', EntityType::class, [
                'class' => Message::class,
                'choice_label' => 'id',
            ])
            ->add('ressources', EntityType::class, [
                'class' => Ressource::class,
                'choice_label' => 'id',
                'multiple' => true,
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => RenduActivite::class,
        ]);
    }
}
