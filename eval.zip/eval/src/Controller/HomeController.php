<?php

namespace App\Controller;

use App\Repository\MessageRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class HomeController extends AbstractController
{
    #[Route('/', name: 'home')]
    public function index(MessageRepository $messageRepository): Response
    {
        $user = $this->getUser();

        if (!$user) {
            return $this->redirectToRoute('app_login');
        }

        $messagesRecus = $messageRepository->findBy(
            ['receveur' => $user],
            ['dateHeure' => 'DESC'],
            2
        );

        $parcoursList = $user->getParcours();

        return $this->render('home/public.html.twig', [
            'messagesRecus' => $messagesRecus,
            'parcoursList' => $parcoursList,
        ]);
    }
}