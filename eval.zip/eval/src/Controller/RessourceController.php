<?php

namespace App\Controller;

use App\Entity\Etape;
use App\Entity\Ressource;
use App\Form\RessourceForm;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/ressource')]
#[IsGranted('ROLE_CONSEILLER')]
class RessourceController extends AbstractController
{
    #[Route('/', name: 'app_ressource_index', methods: ['GET'])]
public function index(RessourceRepository $ressourceRepository): Response
{
    return $this->render('ressource/index.html.twig', [
        'ressources' => $ressourceRepository->findAll(),
    ]);
}

    #[Route('/new/{id}', name: 'app_ressource_new', methods: ['GET', 'POST'])]
    public function new(Etape $etape, Request $request, EntityManagerInterface $entityManager): Response
    {
        $ressource = new Ressource();
        $ressource->setEtape($etape);

        $form = $this->createForm(RessourceForm::class, $ressource);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($ressource);
            $entityManager->flush();

            return $this->redirectToRoute('app_parcours_show', [
                'id' => $etape->getParcours()->getId()
            ]);
        }

        return $this->render('ressource/new.html.twig', [
            'form' => $form,
            'ressource' => $ressource,
        ]);
    }
}
