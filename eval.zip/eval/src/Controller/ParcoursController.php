<?php

namespace App\Controller;

use App\Entity\Parcours;
use App\Form\ParcoursForm;
use App\Repository\ParcoursRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/parcours')]
class ParcoursController extends AbstractController
{
    #[Route('/', name: 'app_parcours_index', methods: ['GET'])]
    #[IsGranted('ROLE_CONSEILLER')]
    public function index(ParcoursRepository $parcoursRepository): Response
    {
        return $this->render('parcours/index.html.twig', [
            'parcours' => $parcoursRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_parcours_new', methods: ['GET', 'POST'])]
    #[IsGranted('ROLE_CONSEILLER')]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $parcour = new Parcours();
        $form = $this->createForm(ParcoursForm::class, $parcour);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($parcour);
            $entityManager->flush();

            return $this->redirectToRoute('app_parcours_index');
        }

        return $this->render('parcours/new.html.twig', [
            'form' => $form,
            'parcour' => $parcour,
        ]);
    }

    #[Route('/{id}', name: 'app_parcours_show', methods: ['GET'])]
    #[IsGranted('ROLE_CONSEILLER')]
    public function show(Parcours $parcour): Response
    {
        return $this->render('parcours/show.html.twig', [
            'parcour' => $parcour,
        ]);
    }

    #[Route('/mon-parcours', name: 'app_mon_parcours', methods: ['GET'])]
    #[IsGranted('ROLE_CANDIDAT')]
    public function monParcours(): Response
    {
        $user = $this->getUser();
        $parcours = $user->getParcours()->first(); // on suppose un seul parcours

        return $this->render('parcours/mon_parcours.html.twig', [
            'parcours' => $parcours,
        ]);
    }
}
