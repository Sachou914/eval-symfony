<?php

namespace App\Controller;

use App\Entity\Etape;
use App\Entity\Parcours;
use App\Form\EtapeForm;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/etape')]
#[IsGranted('ROLE_CONSEILLER')]
class EtapeController extends AbstractController
{
    #[Route('/new/{id}', name: 'app_etape_new', methods: ['GET', 'POST'])]
    public function new(Parcours $parcours, Request $request, EntityManagerInterface $entityManager): Response
    {
        $etape = new Etape();
        $etape->setParcours($parcours);

        $form = $this->createForm(EtapeForm::class, $etape);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($etape);
            $entityManager->flush();

            return $this->redirectToRoute('app_parcours_show', ['id' => $parcours->getId()]);
        }

        return $this->render('etape/new.html.twig', [
            'form' => $form,
            'etape' => $etape,
        ]);
    }
    #[Route('/', name: 'app_etape_index', methods: ['GET'])]
#[IsGranted('ROLE_CONSEILLER')]
public function index(EtapeRepository $etapeRepository): Response
{
    return $this->render('etape/index.html.twig', [
        'etapes' => $etapeRepository->findAll(),
    ]);
}

}
