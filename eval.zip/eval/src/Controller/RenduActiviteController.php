<?php

namespace App\Controller;

use App\Entity\RenduActivite;
use App\Entity\Etape;
use App\Form\RenduActiviteForm;
use App\Repository\RenduActiviteRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/rendu/activite')]
#[IsGranted('ROLE_CANDIDAT')]
final class RenduActiviteController extends AbstractController
{
    #[Route(name: 'app_rendu_activite_index', methods: ['GET'])]
    public function index(RenduActiviteRepository $renduActiviteRepository): Response
    {
        $user = $this->getUser();
        return $this->render('rendu_activite/index.html.twig', [
            'rendu_activites' => $renduActiviteRepository->findBy(['user' => $user]),
        ]);
    }

    #[Route('/new', name: 'app_rendu_activite_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $renduActivite = new RenduActivite();
        $form = $this->createForm(RenduActiviteForm::class, $renduActivite);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $renduActivite->setUser($this->getUser());
            $renduActivite->setDateHeure(new \DateTimeImmutable());

            $entityManager->persist($renduActivite);
            $entityManager->flush();

            return $this->redirectToRoute('app_rendu_activite_index');
        }

        return $this->render('rendu_activite/new.html.twig', [
            'form' => $form,
            'rendu_activite' => $renduActivite,
        ]);
    }

    #[Route('/{id}', name: 'app_rendu_activite_show', methods: ['GET'])]
    public function show(RenduActivite $renduActivite): Response
    {
        // Sécurité : seuls le user concerné peut voir
        if ($renduActivite->getUser() !== $this->getUser()) {
            throw $this->createAccessDeniedException();
        }

        return $this->render('rendu_activite/show.html.twig', [
            'rendu_activite' => $renduActivite,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_rendu_activite_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, RenduActivite $renduActivite, EntityManagerInterface $entityManager): Response
    {
        if ($renduActivite->getUser() !== $this->getUser()) {
            throw $this->createAccessDeniedException();
        }

        $form = $this->createForm(RenduActiviteForm::class, $renduActivite);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_rendu_activite_index');
        }

        return $this->render('rendu_activite/edit.html.twig', [
            'form' => $form,
            'rendu_activite' => $renduActivite,
        ]);
    }

    #[Route('/{id}', name: 'app_rendu_activite_delete', methods: ['POST'])]
    public function delete(Request $request, RenduActivite $renduActivite, EntityManagerInterface $entityManager): Response
    {
        if ($renduActivite->getUser() !== $this->getUser()) {
            throw $this->createAccessDeniedException();
        }

        if ($this->isCsrfTokenValid('delete'.$renduActivite->getId(), $request->getPayload()->getString('_token'))) {
            $entityManager->remove($renduActivite);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_rendu_activite_index');
    }

    #[Route('/upload/{etapeId}', name: 'app_rendu_upload', methods: ['POST'])]
    public function upload(Request $request, int $etapeId, EntityManagerInterface $em): Response
    {
        $etape = $em->getRepository(Etape::class)->find($etapeId);
        $user = $this->getUser();
        $file = $request->files->get('document');

        if ($etape && $file) {
            $filename = uniqid() . '.' . $file->guessExtension();
            $file->move($this->getParameter('uploads_dir'), $filename);

            $rendu = new RenduActivite();
            $rendu->setUser($user);
            $rendu->setDateHeure(new \DateTimeImmutable());
            $rendu->setUrlDocument('uploads/' . $filename);
            $rendu->addEtape($etape);

            $em->persist($rendu);
            $em->flush();
        }

        return $this->redirectToRoute('app_mon_parcours');
    }
}
