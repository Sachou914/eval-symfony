<?php

namespace App\DataFixtures;

use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class UserFixture extends Fixture
{
    public function __construct(
        private UserPasswordHasherInterface $passwordHasher
    ) {}

    public function load(ObjectManager $manager): void
    {
        // 👤 Admin
        $admin = new User();
        $admin->setEmail('admin@example.com');
        $admin->setPrenom('Admin');
        $admin->setNom('Principal');
        $admin->setIsAdmin(true);
        $admin->setRoles(['ROLE_ADMIN']);
        $admin->setPassword($this->passwordHasher->hashPassword($admin, 'admin123'));
        $manager->persist($admin);

        // 👤 Conseiller
        $conseiller = new User();
        $conseiller->setEmail('conseiller@example.com');
        $conseiller->setPrenom('Claire');
        $conseiller->setNom('Conseil');
        $conseiller->setIsAdmin(false);
        $conseiller->setRoles(['ROLE_CONSEILLER']);
        $conseiller->setPassword($this->passwordHasher->hashPassword($conseiller, 'conseil123'));
        $manager->persist($conseiller);

        // 👤 Candidat
        $candidat = new User();
        $candidat->setEmail('candidat@example.com');
        $candidat->setPrenom('Camille');
        $candidat->setNom('Candidat');
        $candidat->setIsAdmin(false);
        $candidat->setRoles(['ROLE_CANDIDAT']);
        $candidat->setPassword($this->passwordHasher->hashPassword($candidat, 'candidat123'));
        $manager->persist($candidat);

        $manager->flush();
    }
}
