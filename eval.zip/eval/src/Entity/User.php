<?php

namespace App\Entity;

use App\Repository\UserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;

#[ORM\Entity(repositoryClass: UserRepository::class)]
#[UniqueEntity(fields: ['email'], message: 'Un compte existe déjà avec cet email.')]
class User implements UserInterface, PasswordAuthenticatedUserInterface
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 180, unique: true)]
    private ?string $email = null;

    #[ORM\Column(length: 255)]
    private ?string $prenom = null;

    #[ORM\Column(length: 255)]
    private ?string $nom = null;

    #[ORM\Column(type: 'json')]
    private array $roles = [];

    #[ORM\Column]
    private ?string $password = null;

    #[ORM\OneToMany(mappedBy: 'emetteur', targetEntity: Message::class)]
    private Collection $messagesEnvoyes;

    #[ORM\OneToMany(mappedBy: 'receveur', targetEntity: Message::class)]
    private Collection $messagesRecus;

    #[ORM\OneToMany(mappedBy: 'accepte', targetEntity: RendezVous::class)]
    private Collection $rendezVousProposes;

    #[ORM\OneToMany(mappedBy: 'user', targetEntity: RenduActivite::class)]
    private Collection $rendus;

    #[ORM\ManyToOne(targetEntity: self::class, inversedBy: 'accompagnes')]
    private ?self $accompagnateur = null;

    #[ORM\OneToMany(mappedBy: 'accompagnateur', targetEntity: self::class)]
    private Collection $accompagnes;

    #[ORM\OneToMany(mappedBy: 'user', targetEntity: Parcours::class)]
    private Collection $parcours;

    public function __construct()
    {
        $this->messagesEnvoyes = new ArrayCollection();
        $this->messagesRecus = new ArrayCollection();
        $this->rendezVousProposes = new ArrayCollection();
        $this->rendus = new ArrayCollection();
        $this->accompagnes = new ArrayCollection();
        $this->parcours = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): static
    {
        $this->email = $email;
        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): static
    {
        $this->prenom = $prenom;
        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): static
    {
        $this->nom = $nom;
        return $this;
    }

    public function getUserIdentifier(): string
    {
        return $this->email;
    }

    public function getRoles(): array
    {
        $roles = $this->roles;
        $roles[] = 'ROLE_USER';
        return array_unique($roles);
    }

    public function setRoles(array $roles): static
    {
        $this->roles = $roles;
        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->password;
    }

    public function setPassword(string $password): static
    {
        $this->password = $password;
        return $this;
    }

    public function eraseCredentials(): void {}

    public function getMessagesEnvoyes(): Collection
    {
        return $this->messagesEnvoyes;
    }

    public function addMessagesEnvoye(Message $messagesEnvoye): static
    {
        if (!$this->messagesEnvoyes->contains($messagesEnvoye)) {
            $this->messagesEnvoyes->add($messagesEnvoye);
            $messagesEnvoye->setEmetteur($this);
        }

        return $this;
    }

    public function removeMessagesEnvoye(Message $messagesEnvoye): static
    {
        if ($this->messagesEnvoyes->removeElement($messagesEnvoye)) {
            if ($messagesEnvoye->getEmetteur() === $this) {
                $messagesEnvoye->setEmetteur(null);
            }
        }

        return $this;
    }

    public function getMessagesRecus(): Collection
    {
        return $this->messagesRecus;
    }

    public function addMessagesRecu(Message $messagesRecu): static
    {
        if (!$this->messagesRecus->contains($messagesRecu)) {
            $this->messagesRecus->add($messagesRecu);
            $messagesRecu->setReceveur($this);
        }

        return $this;
    }

    public function removeMessagesRecu(Message $messagesRecu): static
    {
        if ($this->messagesRecus->removeElement($messagesRecu)) {
            if ($messagesRecu->getReceveur() === $this) {
                $messagesRecu->setReceveur(null);
            }
        }

        return $this;
    }

    public function getRendezVousProposes(): Collection
    {
        return $this->rendezVousProposes;
    }

    public function addRendezVousPropose(RendezVous $rendezVousPropose): static
    {
        if (!$this->rendezVousProposes->contains($rendezVousPropose)) {
            $this->rendezVousProposes->add($rendezVousPropose);
            $rendezVousPropose->setAccepte($this);
        }

        return $this;
    }

    public function removeRendezVousPropose(RendezVous $rendezVousPropose): static
    {
        if ($this->rendezVousProposes->removeElement($rendezVousPropose)) {
            if ($rendezVousPropose->getAccepte() === $this) {
                $rendezVousPropose->setAccepte(null);
            }
        }

        return $this;
    }

    public function getRendus(): Collection
    {
        return $this->rendus;
    }

    public function addRendu(RenduActivite $rendu): static
    {
        if (!$this->rendus->contains($rendu)) {
            $this->rendus->add($rendu);
            $rendu->setUser($this);
        }

        return $this;
    }

    public function removeRendu(RenduActivite $rendu): static
    {
        if ($this->rendus->removeElement($rendu)) {
            if ($rendu->getUser() === $this) {
                $rendu->setUser(null);
            }
        }

        return $this;
    }

    public function getAccompagnateur(): ?self
    {
        return $this->accompagnateur;
    }

    public function setAccompagnateur(?self $accompagnateur): static
    {
        $this->accompagnateur = $accompagnateur;
        return $this;
    }

    public function getAccompagnes(): Collection
    {
        return $this->accompagnes;
    }

    public function addAccompagne(self $accompagne): static
    {
        if (!$this->accompagnes->contains($accompagne)) {
            $this->accompagnes->add($accompagne);
            $accompagne->setAccompagnateur($this);
        }

        return $this;
    }

    public function removeAccompagne(self $accompagne): static
    {
        if ($this->accompagnes->removeElement($accompagne)) {
            if ($accompagne->getAccompagnateur() === $this) {
                $accompagne->setAccompagnateur(null);
            }
        }

        return $this;
    }

    public function getParcours(): Collection
    {
        return $this->parcours;
    }

    public function addParcour(Parcours $parcour): static
    {
        if (!$this->parcours->contains($parcour)) {
            $this->parcours->add($parcour);
            $parcour->setUser($this);
        }

        return $this;
    }

    public function removeParcour(Parcours $parcour): static
    {
        if ($this->parcours->removeElement($parcour)) {
            if ($parcour->getUser() === $this) {
                $parcour->setUser(null);
            }
        }

        return $this;
    }
}
