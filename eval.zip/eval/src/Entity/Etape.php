<?php

namespace App\Entity;

use App\Repository\EtapeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EtapeRepository::class)]
class Etape
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $descriptif = null;

    #[ORM\Column(length: 255)]
    private ?string $consignes = null;

    #[ORM\Column]
    private ?int $position = null;

    #[ORM\ManyToOne(inversedBy: 'etapes')]
    private ?Message $parcours = null;

    /**
     * @var Collection<int, Ressource>
     */
    #[ORM\OneToMany(targetEntity: Ressource::class, mappedBy: 'etape')]
    private Collection $ressources;

    /**
     * @var Collection<int, RenduActivite>
     */
    #[ORM\ManyToMany(targetEntity: RenduActivite::class, inversedBy: 'etapes')]
    private Collection $rendus;

    public function __construct()
    {
        $this->ressources = new ArrayCollection();
        $this->rendus = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDescriptif(): ?string
    {
        return $this->descriptif;
    }

    public function setDescriptif(string $descriptif): static
    {
        $this->descriptif = $descriptif;

        return $this;
    }

    public function getConsignes(): ?string
    {
        return $this->consignes;
    }

    public function setConsignes(string $consignes): static
    {
        $this->consignes = $consignes;

        return $this;
    }

    public function getPosition(): ?int
    {
        return $this->position;
    }

    public function setPosition(int $position): static
    {
        $this->position = $position;

        return $this;
    }

    public function getParcours(): ?Message
    {
        return $this->parcours;
    }

    public function setParcours(?Message $parcours): static
    {
        $this->parcours = $parcours;

        return $this;
    }

    /**
     * @return Collection<int, Ressource>
     */
    public function getRessources(): Collection
    {
        return $this->ressources;
    }

    public function addRessource(Ressource $ressource): static
    {
        if (!$this->ressources->contains($ressource)) {
            $this->ressources->add($ressource);
            $ressource->setEtape($this);
        }

        return $this;
    }

    public function removeRessource(Ressource $ressource): static
    {
        if ($this->ressources->removeElement($ressource)) {
            // set the owning side to null (unless already changed)
            if ($ressource->getEtape() === $this) {
                $ressource->setEtape(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, RenduActivite>
     */
    public function getRendus(): Collection
    {
        return $this->rendus;
    }

    public function addRendu(RenduActivite $rendu): static
    {
        if (!$this->rendus->contains($rendu)) {
            $this->rendus->add($rendu);
        }

        return $this;
    }

    public function removeRendu(RenduActivite $rendu): static
    {
        $this->rendus->removeElement($rendu);

        return $this;
    }
}
