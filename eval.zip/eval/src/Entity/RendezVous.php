<?php

namespace App\Entity;

use App\Repository\RendezVousRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: RendezVousRepository::class)]
class RendezVous
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column]
    private ?\DateTimeImmutable $dateHeure = null;

    #[ORM\Column]
    private ?bool $effectue = null;

    #[ORM\Column(length: 255)]
    private ?string $modalite = null;

    #[ORM\ManyToOne(inversedBy: 'rendezVousProposes')]
    private ?User $accepte = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateHeure(): ?\DateTimeImmutable
    {
        return $this->dateHeure;
    }

    public function setDateHeure(\DateTimeImmutable $dateHeure): static
    {
        $this->dateHeure = $dateHeure;

        return $this;
    }

    public function isEffectue(): ?bool
    {
        return $this->effectue;
    }

    public function setEffectue(bool $effectue): static
    {
        $this->effectue = $effectue;

        return $this;
    }

    public function getModalite(): ?string
    {
        return $this->modalite;
    }

    public function setModalite(string $modalite): static
    {
        $this->modalite = $modalite;

        return $this;
    }

    public function getAccepte(): ?User
    {
        return $this->accepte;
    }

    public function setAccepte(?User $accepte): static
    {
        $this->accepte = $accepte;

        return $this;
    }
}
