<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20250514121201 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql(<<<'SQL'
            CREATE TABLE etape (id INT AUTO_INCREMENT NOT NULL, parcours_id INT DEFAULT NULL, descriptif VARCHAR(255) NOT NULL, consignes VARCHAR(255) NOT NULL, position INT NOT NULL, INDEX IDX_285F75DD6E38C0DB (parcours_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE etape_rendu_activite (etape_id INT NOT NULL, rendu_activite_id INT NOT NULL, INDEX IDX_36B6DEA94A8CA2AD (etape_id), INDEX IDX_36B6DEA919FF918B (rendu_activite_id), PRIMARY KEY(etape_id, rendu_activite_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE message (id INT AUTO_INCREMENT NOT NULL, emetteur_id INT DEFAULT NULL, receveur_id INT DEFAULT NULL, reponse_a_id INT DEFAULT NULL, user_id INT DEFAULT NULL, titre VARCHAR(255) NOT NULL, contenu VARCHAR(255) NOT NULL, date_heure DATETIME NOT NULL COMMENT '(DC2Type:datetime_immutable)', INDEX IDX_B6BD307F79E92E8C (emetteur_id), INDEX IDX_B6BD307FB967E626 (receveur_id), UNIQUE INDEX UNIQ_B6BD307F7B51A1B (reponse_a_id), INDEX IDX_B6BD307FA76ED395 (user_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE parcours (id INT AUTO_INCREMENT NOT NULL, objet VARCHAR(255) NOT NULL, description VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE rendez_vous (id INT AUTO_INCREMENT NOT NULL, accepte_id INT DEFAULT NULL, date_heure DATETIME NOT NULL COMMENT '(DC2Type:datetime_immutable)', effectue TINYINT(1) NOT NULL, modalite VARCHAR(255) NOT NULL, INDEX IDX_65E8AA0AAD232E9E (accepte_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE rendu_activite (id INT AUTO_INCREMENT NOT NULL, user_id INT DEFAULT NULL, message_id INT DEFAULT NULL, url_document VARCHAR(255) NOT NULL, date_heure DATETIME NOT NULL COMMENT '(DC2Type:datetime_immutable)', INDEX IDX_88D477C9A76ED395 (user_id), UNIQUE INDEX UNIQ_88D477C9537A1329 (message_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE rendu_activite_ressource (rendu_activite_id INT NOT NULL, ressource_id INT NOT NULL, INDEX IDX_F7C5B35D19FF918B (rendu_activite_id), INDEX IDX_F7C5B35DFC6CD52A (ressource_id), PRIMARY KEY(rendu_activite_id, ressource_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            CREATE TABLE ressource (id INT AUTO_INCREMENT NOT NULL, etape_id INT DEFAULT NULL, intitule VARCHAR(255) NOT NULL, presentation LONGTEXT NOT NULL, support VARCHAR(255) NOT NULL, nature VARCHAR(255) NOT NULL, url_document VARCHAR(255) NOT NULL, INDEX IDX_939F45444A8CA2AD (etape_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE etape ADD CONSTRAINT FK_285F75DD6E38C0DB FOREIGN KEY (parcours_id) REFERENCES message (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE etape_rendu_activite ADD CONSTRAINT FK_36B6DEA94A8CA2AD FOREIGN KEY (etape_id) REFERENCES etape (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE etape_rendu_activite ADD CONSTRAINT FK_36B6DEA919FF918B FOREIGN KEY (rendu_activite_id) REFERENCES rendu_activite (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message ADD CONSTRAINT FK_B6BD307F79E92E8C FOREIGN KEY (emetteur_id) REFERENCES user (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message ADD CONSTRAINT FK_B6BD307FB967E626 FOREIGN KEY (receveur_id) REFERENCES user (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message ADD CONSTRAINT FK_B6BD307F7B51A1B FOREIGN KEY (reponse_a_id) REFERENCES message (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message ADD CONSTRAINT FK_B6BD307FA76ED395 FOREIGN KEY (user_id) REFERENCES user (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendez_vous ADD CONSTRAINT FK_65E8AA0AAD232E9E FOREIGN KEY (accepte_id) REFERENCES user (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite ADD CONSTRAINT FK_88D477C9A76ED395 FOREIGN KEY (user_id) REFERENCES user (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite ADD CONSTRAINT FK_88D477C9537A1329 FOREIGN KEY (message_id) REFERENCES message (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite_ressource ADD CONSTRAINT FK_F7C5B35D19FF918B FOREIGN KEY (rendu_activite_id) REFERENCES rendu_activite (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite_ressource ADD CONSTRAINT FK_F7C5B35DFC6CD52A FOREIGN KEY (ressource_id) REFERENCES ressource (id) ON DELETE CASCADE
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE ressource ADD CONSTRAINT FK_939F45444A8CA2AD FOREIGN KEY (etape_id) REFERENCES etape (id)
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user ADD accompagnateur_id INT DEFAULT NULL
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user ADD CONSTRAINT FK_8D93D649CA21A6AD FOREIGN KEY (accompagnateur_id) REFERENCES user (id)
        SQL);
        $this->addSql(<<<'SQL'
            CREATE INDEX IDX_8D93D649CA21A6AD ON user (accompagnateur_id)
        SQL);
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql(<<<'SQL'
            ALTER TABLE etape DROP FOREIGN KEY FK_285F75DD6E38C0DB
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE etape_rendu_activite DROP FOREIGN KEY FK_36B6DEA94A8CA2AD
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE etape_rendu_activite DROP FOREIGN KEY FK_36B6DEA919FF918B
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message DROP FOREIGN KEY FK_B6BD307F79E92E8C
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message DROP FOREIGN KEY FK_B6BD307FB967E626
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message DROP FOREIGN KEY FK_B6BD307F7B51A1B
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE message DROP FOREIGN KEY FK_B6BD307FA76ED395
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendez_vous DROP FOREIGN KEY FK_65E8AA0AAD232E9E
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite DROP FOREIGN KEY FK_88D477C9A76ED395
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite DROP FOREIGN KEY FK_88D477C9537A1329
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite_ressource DROP FOREIGN KEY FK_F7C5B35D19FF918B
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE rendu_activite_ressource DROP FOREIGN KEY FK_F7C5B35DFC6CD52A
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE ressource DROP FOREIGN KEY FK_939F45444A8CA2AD
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE etape
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE etape_rendu_activite
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE message
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE parcours
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE rendez_vous
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE rendu_activite
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE rendu_activite_ressource
        SQL);
        $this->addSql(<<<'SQL'
            DROP TABLE ressource
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user DROP FOREIGN KEY FK_8D93D649CA21A6AD
        SQL);
        $this->addSql(<<<'SQL'
            DROP INDEX IDX_8D93D649CA21A6AD ON user
        SQL);
        $this->addSql(<<<'SQL'
            ALTER TABLE user DROP accompagnateur_id
        SQL);
    }
}
